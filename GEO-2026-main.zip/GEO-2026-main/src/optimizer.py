import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution
from datetime import date

from model import TailorOracle

class WorkshopOptimizer:
    def __init__(self, oracle: TailorOracle, X_large=1e9):
        self.oracle = oracle
        self.X = X_large
        self.projects = {} 
        self.tailors = {}  
        self.IDLE_PENALTY = -(X_large**2) # High penalty for having no work

    def add_project(self, project_id, deadline_date, clothes_type, quota):
        if isinstance(deadline_date, str):
            deadline_date = pd.to_datetime(deadline_date, dayfirst=True).date()
        self.projects[project_id] = {'deadline': deadline_date, 'type': clothes_type, 'quota': quota}

    def initialize_tailors(self, df_mapping: pd.DataFrame):
        for _, row in df_mapping.drop_duplicates(subset=['Name']).iterrows():
            name = row['Name'].strip()
            self.tailors[name] = {
                'spec': row['Specialist'].strip(),
                'current_alloc': None,
                'current_j': self.IDLE_PENALTY
            }

    def _calculate_individual_j(self, name, clothes_type, amount, start_day, deadline_day, spec):
        window = (deadline_day - start_day).days
        if window <= 0: return -self.X
        
        # 1. Oracle predicts Pcs/Day
        predicted_rate = self.oracle.predict_rate(name, clothes_type, amount, spec)
        
        # 2. Formula: (Capacity - Assigned)^2
        # Capacity = Rate * Window
        capacity = predicted_rate * window
        surplus = capacity - amount
        
        # A_i: Specialist weight
        ability = 2.0 if spec == "All" else 1.0
        
        # Lateness Check: If surplus is negative, tailor is overworked
        if surplus < 0:
            return -(self.X + abs(surplus) * 1e6)
            
        return ability * (surplus ** 2)

    def _objective(self, weights, target_project_id, realloc_tailors, reschedule_date, current_total_j):
        if np.sum(weights) == 0: return self.X**2
        
        proj = self.projects[target_project_id]
        props = weights / np.sum(weights)
        qtys = np.round(props * proj['quota']).astype(int)
        
        # Fix rounding
        diff = proj['quota'] - np.sum(qtys)
        qtys[np.argmax(qtys)] += diff
        
        changed_j_sum = 0
        for i, name in enumerate(realloc_tailors):
            tailor = self.tailors[name]
            qty = qtys[i]
            
            new_j = self._calculate_individual_j(
                name, proj['type'], qty, reschedule_date, proj['deadline'], tailor['spec']
            ) if qty > 0 else self.IDLE_PENALTY
            
            changed_j_sum += (new_j - tailor['current_j'])
            
        return -(current_total_j + changed_j_sum) # Minimize negative J to Maximize J

    def reallocate(self, project_id, tailor_names: list, reschedule_date: date):
        current_total_j = sum(t['current_j'] for t in self.tailors.values())
        bounds = [(0, 1)] * len(tailor_names)
        
        res = differential_evolution(
            self._objective, bounds, 
            args=(project_id, tailor_names, reschedule_date, current_total_j),
            popsize=15, tol=0.01
        )
        
        # Decode and Update State
        props = res.x / np.sum(res.x)
        final_qtys = np.round(props * self.projects[project_id]['quota']).astype(int)
        diff = self.projects[project_id]['quota'] - np.sum(final_qtys)
        final_qtys[np.argmax(final_qtys)] += diff
        
        final_plan = {}
        for i, name in enumerate(tailor_names):
            qty = int(final_qtys[i])
            self.tailors[name]['current_alloc'] = {'project': project_id, 'amount': qty, 'start': reschedule_date}
            self.tailors[name]['current_j'] = self._calculate_individual_j(
                name, self.projects[project_id]['type'], qty, 
                reschedule_date, self.projects[project_id]['deadline'], self.tailors[name]['spec']
            ) if qty > 0 else self.IDLE_PENALTY
            final_plan[name] = qty
            
        return final_plan